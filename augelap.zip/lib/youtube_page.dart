import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'constants.dart';

// --- MODEL DATA VIDEO ---
class VideoData {
  final String id;
  final String title;
  final String author;
  final String thumbnail;

  VideoData({
    required this.id,
    required this.title,
    required this.author,
    required this.thumbnail,
  });
}

// --- GLOBAL NOTIFIER ---
final ValueNotifier<VideoData?> globalVideoNotifier = ValueNotifier<VideoData?>(null);

class YoutubeSearchPage extends StatefulWidget {
  const YoutubeSearchPage({super.key});

  @override
  State<YoutubeSearchPage> createState() => _YoutubeSearchPageState();
}

class _YoutubeSearchPageState extends State<YoutubeSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  List<dynamic> _searchResults = [];
  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _searchYoutube() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _searchResults = [];
    });

    try {
      final url = Uri.parse("https://qwerty-api.cloud/sr/yt?query=$query");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        // Cek status dan ambil result
        if (data['status'] == true && data['result'] != null) {
          setState(() {
            _searchResults = (data['result'] as List)
                .where((item) => item['type'] == 'video') // Filter hanya video
                .toList();
          });
        } else {
          setState(() => _errorMessage = "Tidak ditemukan hasil.");
        }
      } else {
        setState(() => _errorMessage = "API Error: ${response.statusCode}");
      }
    } catch (e) {
      setState(() => _errorMessage = "Error: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _playVideo(dynamic video) {
    // Masukkan data ke Global Notifier
    globalVideoNotifier.value = VideoData(
      id: video['videoId'],
      title: video['title'] ?? "Unknown Title",
      author: video['author']?['name'] ?? "Unknown Artist", // Sesuai JSON baru
      thumbnail: video['thumbnail'] ?? "",
    );
    
    FocusScope.of(context).unfocus();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Playing: ${video['title']}", style: const TextStyle(fontFamily: 'Orbitron', fontSize: 12)),
        backgroundColor: accentPink.withOpacity(0.8),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.only(bottom: 100, left: 10, right: 10), // Naikkan snackbar
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: const Text("SaturnX Music", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        backgroundColor: primaryDark,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: accentPink.withOpacity(0.3)),
                boxShadow: [
                  const BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0,4))
                ]
              ),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: "Search Songs...",
                  hintStyle: const TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                  prefixIcon: const Icon(Icons.search, color: accentPink),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.send, color: successGreen),
                    onPressed: _searchYoutube,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                onSubmitted: (_) => _searchYoutube(),
              ),
            ),
          ),

          // Content List
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(color: accentPink))
                : _errorMessage != null
                    ? Center(child: Text(_errorMessage!, style: const TextStyle(color: dangerRed)))
                    : ListView.builder(
                        itemCount: _searchResults.length,
                        // PENTING: Tambahkan padding bawah besar agar item terakhir tidak ketutupan Player
                        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 150), 
                        itemBuilder: (context, index) {
                          final video = _searchResults[index];
                          return _buildVideoCard(video);
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoCard(dynamic video) {
    return GestureDetector(
      onTap: () => _playVideo(video),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: cardDarker.withOpacity(0.6),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(
          children: [
            // Thumbnail
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                video['thumbnail'] ?? "",
                height: 60,
                width: 60,
                fit: BoxFit.cover,
                errorBuilder: (_,__,___) => Container(height: 60, width: 60, color: Colors.grey[900]),
              ),
            ),
            const SizedBox(width: 12),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    video['title'] ?? "No Title",
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    video['author']?['name'] ?? "Unknown",
                    style: const TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
            // Duration
            Text(
              video['timestamp'] ?? "",
              style: const TextStyle(color: accentPink, fontSize: 12, fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}

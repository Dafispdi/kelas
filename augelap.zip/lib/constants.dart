import 'package:flutter/material.dart';

// --- TEMA SATURNX: COSMIC VIOLET (REVISED) ---
const String baseUrl = "http://privserv.my.id:2305"; 

const Color primaryDark = Color(0xFF05000A);   // Background paling gelap
const Color deepSpace = Color(0xFF1A052E);     // Ungu sangat tua untuk gradasi

// Card & Surface
const Color cardDarker = Color(0xFF0F021D);    // Card background
const Color cardDark = Color(0xFF2A0944);      // Card highlight

// Accent: Ungu Neon yang lebih "Electric"
const Color accentPink = Color(0xFFCF3FFF);    // Ungu Neon Terang (Glow utama)
const Color primaryPink = Color(0xFF9616D0);   // Ungu Solid (Primary button)
const Color lightPink = Color(0xFFF2C4FF);     // Highlight putih keunguan

// Warna Status (Disesuaikan agar tidak terlalu merah 'cabe')
const Color dangerRed = Color(0xFFFF2E63);     // Merah Cyberpunk (agak pink)
const Color successGreen = Color(0xFF08D9D6);  // Cyan Teal (cocok sama ungu)
const Color warningOrange = Color(0xFFFF9A3C); // Neon Orange

// Utilitas
const Color primaryWhite = Colors.white;
const Color accentGrey = Color(0xFF8D86C9);    // Abu keunguan
const Color glassColor = Colors.white10;

// TAMBAHKAN CLASS INI DI PALING BAWAH FILE
class SaturnXBackground extends StatelessWidget {
  final Widget child;
 
  final String gifPath = "assets/video/saturn.gif"; 

  const SaturnXBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Layer Background Gelap (Fallback jika GIF tidak ada)
        Container(color: const Color(0xFF05000A)),

        // Layer GIF (Opsional, bungkus dengan try-catch jika perlu aman)
        Positioned.fill(
          child: Opacity(
            opacity: 0.6, // Sesuaikan transparansi
            child: Image.asset(
              gifPath,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(color: const Color(0xFF05000A)); // Fallback jika gambar error
              },
            ),
          ),
        ),
 
        // Layer Overlay Gelap biar tulisan terbaca
        Positioned.fill(
          child: Container(
            color: const Color(0xFF05000A).withOpacity(0.8), 
          ),
        ),

        // Konten Halaman
        child,
      ],
    );
  }
}
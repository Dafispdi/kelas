import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'constants.dart'; // Pastikan file constants.dart ada

class TestFunctionPage extends StatefulWidget {
  final String sessionKey;

  const TestFunctionPage({super.key, required this.sessionKey});

  @override
  State<TestFunctionPage> createState() => _TestFunctionPageState();
}

class _TestFunctionPageState extends State<TestFunctionPage> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _delayController = TextEditingController(text: "1000");
  final TextEditingController _loopController = TextEditingController(text: "1");

  bool _isLoading = false;

  // Default code template mirip video
  final String _defaultCode = """
async function LocaCrashUi(sock, target) {
  console.log('Sending Test...');
  await sock.sendMessage(target, { text: 'Test Function Working!' });
}
""";

  @override
  void initState() {
    super.initState();
    _codeController.text = _defaultCode;
  }

  Future<void> _executeFunction() async {
    if (_targetController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Target Number is required!")),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/tester/execute'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "key": widget.sessionKey,
          "target": _targetController.text,
          "code": _codeController.text,
          "delay": int.tryParse(_delayController.text) ?? 1000,
          "loop": int.tryParse(_loopController.text) ?? 1,
        }),
      );

      final data = jsonDecode(response.body);

      if (data['success'] == true) {
        _showSuccessDialog();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(backgroundColor: dangerRed, content: Text(data['message'] ?? "Failed")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(backgroundColor: dangerRed, content: Text("Error: $e")),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: successGreen.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check, color: successGreen, size: 40),
            ),
            const SizedBox(height: 20),
            const Text(
              "Success",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Function berhasil dikirim!\nSender: Private (Your Session)\nDelay: ${_delayController.text}ms",
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: successGreen),
                onPressed: () => Navigator.pop(context),
                child: const Text("OK", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Test Function", style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.cyan.shade900, Colors.cyanAccent.shade700]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.code, color: Colors.white, size: 30),
                  ),
                  const SizedBox(width: 15),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Funct Bug Tester", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        Text("Execute raw functions via Private Sender", style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 25),

            // Target Input
            const Text("Nomor Target", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _targetController,
              keyboardType: TextInputType.phone,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                filled: true,
                fillColor: cardDarker,
                hintText: "628xxx",
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                prefixIcon: const Icon(Icons.phone, color: accentPink),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),

            // Code Input
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Function / Message", style: TextStyle(color: accentPink, fontWeight: FontWeight.bold)),
                GestureDetector(
                  onTap: () {
                    setState(() => _codeController.clear());
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
                    child: const Text("Clear", style: TextStyle(color: Colors.red, fontSize: 12)),
                  ),
                )
              ],
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: cardDarker,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentPink.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _codeController,
                maxLines: 10,
                style: const TextStyle(color: Color(0xFF00FF00), fontFamily: 'Courier'), // Hacker style font
                decoration: const InputDecoration(
                  contentPadding: EdgeInsets.all(15),
                  border: InputBorder.none,
                  hintText: "Paste your function here...",
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Config Row (Delay & Loop)
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Delay (ms)", style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 5),
                      TextField(
                        controller: _delayController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: cardDarker,
                          prefixIcon: const Icon(Icons.timer, color: Colors.orange, size: 18),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Jumlah Loops", style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 5),
                      TextField(
                        controller: _loopController,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: cardDarker,
                          prefixIcon: const Icon(Icons.repeat, color: Colors.blue, size: 18),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),

            // Execute Button
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _executeFunction,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentPink,
                  shadowColor: accentPink.withOpacity(0.5),
                  elevation: 10,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.send_rounded, color: Colors.white),
                          SizedBox(width: 10),
                          Text(
                            "KIRIM TESTER",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

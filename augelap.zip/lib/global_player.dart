import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'constants.dart';
import 'youtube_page.dart'; // Wajib import ini buat ambil notifier

class GlobalPlayerOverlay extends StatefulWidget {
  final Widget child;

  const GlobalPlayerOverlay({super.key, required this.child});

  @override
  State<GlobalPlayerOverlay> createState() => _GlobalPlayerOverlayState();
}

class _GlobalPlayerOverlayState extends State<GlobalPlayerOverlay> {
  YoutubePlayerController? _ytController;
  VideoData? _currentData;
  bool _isPlaying = false;
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    // Dengerin perubahan lagu dari Youtube Page
    globalVideoNotifier.addListener(_onVideoChanged);
  }

  void _onVideoChanged() {
    final data = globalVideoNotifier.value;
    if (data != null) {
      if (_currentData?.id != data.id) {
        _initializePlayer(data.id);
      }
      setState(() {
        _currentData = data;
      });
    } else {
      // Kalau data null (tombol X ditekan), matikan player
      _disposePlayer();
    }
  }

  void _initializePlayer(String videoId) {
    _ytController?.dispose();
    _ytController = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: false,
        hideControls: true, 
        forceHD: false,
        loop: true,
        isLive: false,
      ),
    )..addListener(_playerListener);
  }

  void _disposePlayer() {
    _ytController?.dispose();
    _ytController = null;
    if (mounted) {
      setState(() {
        _currentData = null;
        _isPlaying = false;
        _progress = 0.0;
      });
    }
  }

  void _playerListener() {
    if (_ytController != null && mounted) {
      setState(() {
        _isPlaying = _ytController!.value.isPlaying;
        final duration = _ytController!.value.metaData.duration.inMilliseconds;
        final position = _ytController!.value.position.inMilliseconds;
        if (duration > 0) _progress = position / duration;
      });
    }
  }

  @override
  void dispose() {
    globalVideoNotifier.removeListener(_onVideoChanged);
    _ytController?.dispose();
    super.dispose();
  }

  void _togglePlayPause() {
    if (_ytController != null) {
      _isPlaying ? _ytController!.pause() : _ytController!.play();
    }
  }

  void _closePlayer() {
    globalVideoNotifier.value = null; // Ini akan mentrigger _disposePlayer
  }

  @override
  Widget build(BuildContext context) {
    bool isActive = _currentData != null && _ytController != null;

    return Stack(
      children: [
        // 1. APLIKASI UTAMA (Halaman lain)
        widget.child,

        // 2. PLAYER FLOATING (Hanya muncul jika ada lagu)
        if (isActive)
          Positioned(
            left: 12,
            right: 12,
            bottom: 85, // Di atas Navbar
            child: Material(
              color: Colors.transparent,
              elevation: 15,
              shadowColor: Colors.black.withOpacity(0.5),
              child: Container(
                height: 70,
                decoration: BoxDecoration(
                  color: const Color(0xFF151515), 
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: accentPink.withOpacity(0.3), width: 1),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Stack(
                    children: [
                      Row(
                        children: [
                          // VIDEO VIEW (Hidden Interaction)
                          SizedBox(
                            width: 80,
                            height: 70,
                            child: IgnorePointer(
                              ignoring: true, 
                              child: YoutubePlayer(
                                controller: _ytController!,
                                width: 80,
                                onReady: () {
                                   _ytController!.unMute();
                                   _ytController!.setVolume(100);
                                },
                              ),
                            ),
                          ),

                          // TITLE & ARTIST
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _currentData!.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron'),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    _currentData!.author,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // CONTROLS
                          IconButton(
                            icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled, color: successGreen, size: 34),
                            onPressed: _togglePlayPause,
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: Colors.white54, size: 20),
                            onPressed: _closePlayer,
                          ),
                        ],
                      ),

                      // PROGRESS BAR
                      Positioned(
                        bottom: 0, left: 0, right: 0,
                        child: LinearProgressIndicator(
                          value: _progress.isNaN ? 0 : _progress,
                          backgroundColor: Colors.transparent,
                          valueColor: const AlwaysStoppedAnimation<Color>(successGreen),
                          minHeight: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
